using System;
using System.Windows.Forms;

namespace XBLA_Setup_Editor
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new ToolLauncherForm());
        }
    }
}
